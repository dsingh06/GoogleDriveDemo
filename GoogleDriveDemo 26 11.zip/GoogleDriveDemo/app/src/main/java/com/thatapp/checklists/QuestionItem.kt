package com.thatapp.checklists

data class QuestionItem (var strSno: String?,var strHeading: String?,var strRemark: String?,var categoryId: String)

/*    fun getHeading(): String? {
        return strHeading
    }

    fun setHeading(strHeading: String) {
        this.strHeading = strHeading
    }

    fun setRemark(strRemark :String){
       this.strRemark = strRemark
    }

    fun getRemark():String?{
        return strRemark
    }*/
